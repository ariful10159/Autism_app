<?php
require_once __DIR__ . '/config.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
$pdo = get_db();
$user = current_user();

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    // Handle optional profile photo upload
    $photoPath = null;
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] === UPLOAD_ERR_OK) {
        $allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];
        $mime = mime_content_type($_FILES['photo']['tmp_name']);
        if (!in_array($mime, $allowedTypes)) {
            $error = 'Unsupported profile photo type. Please upload JPG or PNG.';
        } else {
            // Create profile uploads directory
            $profileDir = __DIR__ . '/uploads/profiles';
            if (!file_exists($profileDir)) {
                mkdir($profileDir, 0777, true);
            }
            $ext = pathinfo($_FILES['photo']['name'], PATHINFO_EXTENSION);
            $filename = 'profile_' . $user['id'] . '_' . time() . '.' . $ext;
            $destination = $profileDir . '/' . $filename;
            if (!move_uploaded_file($_FILES['photo']['tmp_name'], $destination)) {
                $error = 'Failed to upload profile photo.';
            } else {
                $photoPath = 'uploads/profiles/' . $filename;
                // Optionally delete old photo
                if ($user['profile_photo']) {
                    $oldPath = __DIR__ . '/' . $user['profile_photo'];
                    if (file_exists($oldPath)) {
                        @unlink($oldPath);
                    }
                }
            }
        }
    }
    if (!$error) {
        if (!$name || !$email) {
            $error = 'Name and email cannot be empty.';
        } else {
            // Check if email exists for another user
            $stmt = $pdo->prepare('SELECT id FROM users WHERE email = :email AND id != :id');
            $stmt->execute([':email' => $email, ':id' => $user['id']]);
            if ($stmt->fetch()) {
                $error = 'This email is already taken.';
            } else {
                // Build update query
                if ($photoPath) {
                    $stmt = $pdo->prepare('UPDATE users SET name = :name, email = :email, profile_photo = :photo WHERE id = :id');
                    $stmt->execute([
                        ':name' => $name,
                        ':email' => $email,
                        ':photo' => $photoPath,
                        ':id' => $user['id']
                    ]);
                } else {
                    $stmt = $pdo->prepare('UPDATE users SET name = :name, email = :email WHERE id = :id');
                    $stmt->execute([
                        ':name' => $name,
                        ':email' => $email,
                        ':id' => $user['id']
                    ]);
                }
                $success = 'Profile updated successfully.';
                // Refresh user data
                $user = current_user();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile - ASD Detection App</title>
    <link rel="stylesheet" href="assets/styles.css">
</head>
<body>
    <header>
        <div class="header-wrapper">
            <img src="assets/autism_art.png" alt="ASD art">
            <h1>Your Profile</h1>
        </div>
    </header>
    <main>
        <div class="nav">
            <a href="dashboard.php">Dashboard</a>
            <a href="detection.php">Face Detection</a>
            <a href="questionnaire.php">Questionnaire</a>
            <a href="suggestions.php">Suggestions</a>
            <a href="logout.php" style="background-color: #dc3545;">Logout</a>
        </div>
        <div class="container">
            <?php if ($error): ?>
                <p class="error"><?= htmlspecialchars($error) ?></p>
            <?php endif; ?>
            <?php if ($success): ?>
                <p class="success"><?= htmlspecialchars($success) ?></p>
            <?php endif; ?>
            <!-- Profile Picture and Name -->
            <div style="text-align:center; margin-bottom:1rem;">
                <?php if (!empty($user['profile_photo'])): ?>
                    <img src="<?= htmlspecialchars($user['profile_photo']) ?>" alt="Profile Photo" style="width:100px;height:100px;border-radius:50%;object-fit:cover;border:2px solid #007bff;">
                <?php else: ?>
                    <div style="width:100px;height:100px;border-radius:50%;background-color:#dee2e6;display:inline-flex;align-items:center;justify-content:center;font-size:2rem;color:#6c757d;">👤</div>
                <?php endif; ?>
                <h3><?= htmlspecialchars($user['name']) ?></h3>
            </div>
            <form method="post" action="profile.php" enctype="multipart/form-data">
                <label for="name">Name</label>
                <input type="text" name="name" id="name" value="<?= htmlspecialchars($user['name']) ?>" required>
                <label for="email">Email</label>
                <input type="email" name="email" id="email" value="<?= htmlspecialchars($user['email']) ?>" required>
                <label for="photo">Profile Photo (optional)</label>
                <input type="file" name="photo" id="photo" accept="image/*">
                <input type="submit" value="Update Profile">
            </form>
        </div>
    </main>
</body>
</html>