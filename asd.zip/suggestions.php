<?php
require_once __DIR__ . '/config.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
$userId = $_SESSION['user_id'];
$latestDetection = get_latest_detection($userId);
$latestQuestionnaire = get_latest_questionnaire($userId);
// Only generate suggestions if both detection and questionnaire exist
$suggestions = ($latestDetection && $latestQuestionnaire) ? generate_suggestions($userId) : [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personalized Suggestions - ASD Detection App</title>
    <link rel="stylesheet" href="assets/styles.css">
</head>
<body>
    <header>
        <div class="header-wrapper">
            <img src="assets/autism_art.png" alt="ASD art">
            <h1>Personalized Suggestions</h1>
        </div>
    </header>
    <main>
        <div class="nav">
            <a href="dashboard.php">Dashboard</a>
            <a href="detection.php">Face Detection</a>
            <a href="questionnaire.php">Questionnaire</a>
            <a href="profile.php">Profile</a>
            <a href="logout.php" style="background-color: #dc3545;">Logout</a>
        </div>
        <div class="container">
<?php if (!$latestDetection || !$latestQuestionnaire): ?>
                <p>You must complete both the photo upload and the questionnaire to see your personalized evaluation and suggestions.</p>
                <?php if (!$latestDetection): ?>
                    <p>Please visit the <a href="detection.php">Face Detection</a> page to upload your photo.</p>
                <?php endif; ?>
                <?php if (!$latestQuestionnaire): ?>
                    <p>Please visit the <a href="questionnaire.php">Questionnaire</a> page to answer the questions.</p>
                <?php endif; ?>
<?php else: ?>
                <?php
                    // Compute classification based on questionnaire score
                    $answers = json_decode($latestQuestionnaire['answers'], true);
                    $totalQuestions = count($answers);
                    $score = $latestQuestionnaire['score'];
                    $probability = $totalQuestions > 0 ? $score / $totalQuestions : 0;
                    // Use a 50% threshold to decide ASD vs TD
                    $classification = ($score >= ceil($totalQuestions * 0.5)) ? 'ASD' : 'TD';
                ?>
                <p><strong>Photo Status:</strong> Uploaded</p>
                <p><strong>Questionnaire Score:</strong> <?= htmlspecialchars($score) ?> out of <?= $totalQuestions ?></p>
                <p><strong>Evaluation:</strong> <?= $classification ?> (Probability: <?= round($probability * 100, 1) ?>%)</p>
                <div class="suggestions-box">
                    <h2>Personalized Suggestions</h2>
                    <ul class="suggestions">
                        <?php foreach ($suggestions as $suggestion): ?>
                            <li><?= htmlspecialchars($suggestion) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
<?php endif; ?>
        </div>
    </main>
</body>
</html>