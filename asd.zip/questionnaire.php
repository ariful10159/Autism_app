<?php
require_once __DIR__ . '/config.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
$userId = $_SESSION['user_id'];

// Define a set of screening questions. These questions are
// illustrative and not a substitute for professional assessment.
$questions = [
    'Does the individual often avoid eye contact?',
    'Does the individual have difficulty understanding social cues?',
    'Does the individual engage in repetitive behaviors?',
    'Does the individual have difficulty adapting to changes in routine?',
    'Does the individual show unusual reactions to sensory experiences (e.g., sounds, textures)?',
    'Does the individual have difficulty maintaining peer relationships?',
    'Does the individual prefer to be alone rather than engage with others?',
    'Does the individual use very few gestures when communicating?',
    'Does the individual have intense interests in specific topics?',
    'Does the individual have delayed language development?'
];

$submitted = false;
$message = '';
$score = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $answers = [];
    // Collect answers from POST
    foreach ($questions as $idx => $question) {
        $key = 'q' . $idx;
        $answer = $_POST[$key] ?? 'no';
        $answers[$idx] = $answer;
    }
    // Calculate score
    $score = calculate_questionnaire_score($answers);
    // Save to database
    save_questionnaire_result($userId, $answers, $score);
    $submitted = true;
    $message = 'Your questionnaire has been submitted. Your score is ' . $score . ' out of ' . count($questions) . '.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Questionnaire - ASD Detection App</title>
    <link rel="stylesheet" href="assets/styles.css">
</head>
<body>
    <header>
        <div class="header-wrapper">
            <img src="assets/autism_art.png" alt="ASD art">
            <h1>ASD Screening Questionnaire</h1>
        </div>
    </header>
    <main>
        <div class="nav">
            <a href="dashboard.php">Dashboard</a>
            <a href="detection.php">Face Detection</a>
            <a href="suggestions.php">Suggestions</a>
            <a href="profile.php">Profile</a>
            <a href="logout.php" style="background-color: #dc3545;">Logout</a>
        </div>
        <div class="container">
            <?php if ($submitted): ?>
                <p class="success"><?= htmlspecialchars($message) ?></p>
                <p>Please upload a photo to complete the evaluation. After both steps, your results will be available on the <a href="suggestions.php">Suggestions</a> page.</p>
            <?php else: ?>
                <form method="post" action="questionnaire.php">
                    <?php foreach ($questions as $index => $question): ?>
                        <div class="question">
                            <label><?= htmlspecialchars(($index + 1) . '. ' . $question) ?></label><br>
                            <input type="radio" name="q<?= $index ?>" value="yes" required> Yes
                            <input type="radio" name="q<?= $index ?>" value="no"> No
                        </div>
                    <?php endforeach; ?>
                    <input type="submit" value="Submit Questionnaire">
                </form>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>