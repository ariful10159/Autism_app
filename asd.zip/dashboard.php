<?php
require_once __DIR__ . '/config.php';
session_start();
// If not logged in, redirect to login
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}
// Retrieve current user; if retrieval fails, log out and redirect
$user = current_user();
if (!$user) {
    // Session may be invalid; log out and redirect
    logout_user();
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - ASD Detection App</title>
    <link rel="stylesheet" href="assets/styles.css">
</head>
<body>
    <header>
        <div class="header-wrapper">
            <img src="assets/autism_art.png" alt="ASD art">
            <h1>Welcome, <?= htmlspecialchars($user['name']) ?></h1>
        </div>
    </header>
    <main>
        <div class="nav">
            <a href="detection.php">Face Detection</a>
            <a href="questionnaire.php">Questionnaire</a>
            <a href="suggestions.php">Suggestions</a>
            <a href="profile.php">Profile</a>
            <a href="logout.php" style="background-color: #dc3545;">Logout</a>
        </div>
        <div class="container">
            <p>Select an option above to begin. You can take a photo for ASD detection, fill out a questionnaire, view personalized suggestions, or edit your profile.</p>
        </div>
    </main>
</body>
</html>